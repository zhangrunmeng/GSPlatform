/**
 * Created by runmengz on 9/22/2014.
 */
define(['angular'], function(angular){
    angular.module('beacon.DetailModule', ['beacon.services']);
});