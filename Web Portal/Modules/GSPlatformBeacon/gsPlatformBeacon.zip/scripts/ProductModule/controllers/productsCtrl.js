/**
 * Created by runmengz on 9/22/2014.
 */
define(['angular'], function(angular){
    return function ($scope, $element, BeaconUtil, RestUtil) {
        RestUtil.jsonp('repository', function(data){

        });
    };
});