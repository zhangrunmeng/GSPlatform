define(['app/app'], function(){
    'use strict';
});
