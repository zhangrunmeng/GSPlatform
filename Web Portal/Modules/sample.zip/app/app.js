/**
 * Created by hammer on 2014/8/31.
 */
define(['angular',
        'css!./styles/themes/' + $theme + '/css/app'
	   ], function(angular){
			return angular.module('{module}',[]);
	   });